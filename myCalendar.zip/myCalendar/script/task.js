class Task{
    constructor(important, title, desc, location, participants, color, dueDate ){
        this.important = important;
        this.title = title;
        this.description = desc;
        this.location = location;
        this.participants = participants;
        this.color = color;
        this.dueDate = dueDate;

        this.name = "Ray";
    }
}