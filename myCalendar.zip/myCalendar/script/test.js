
function Dog(name, age, color){ //this is an object constructor
// obj constructor should start with capital letter
    this.name = name;
    this.age = age;
    this.color = color;

}

class Lion{
    constructor(name, age, gender){
        this.name = name;
        this.age = 2;
        this.gender = gender;
    }
    roar(){
        console.log("i'm roarrring!");
    }

}

function test1(){
    // ways to create objects on JS
    // 1- object literal(fastest wy to create an object)
    //  obj literal is not re-usable

    let lola = {
        name: "lola",
        age:  2,
    };
    console.log(lola);

    // 2 - object constructor
    let fido = new Dog("Fido", 2, "Black"); //a new "Dog"
    let another = new Dog("Cool dude", 4, "Gray");
    console.log(fido);

    // 3 - class
    let a = new Lion("Simba", 5, "male" );
    console.log(a);

    a.roar();
}

test1();