var isImportant = false;
var isAsideVisible = true;

function toggleImportant(){
    let icon = $(".iImportant");
    if(isImportant){
        icon.removeClass("fas").addClass("far");
        isImportant = false;
    }
    else{
    icon.removeClass("far").addClass("fas");
    isImportant = true;
    }
}

function toggleDetails(){
    let aside = $("aside");
    if(isAsideVisible){
        aside.hide();
        isAsideVisible = false;
    }
    else{
        aside.show();
        isAsideVisible = true;
    }

}

function saveTask(){
    //console.log("Saving Task")
    let title = $("#txtTitle").val();
    let date = $("#txtDueDate").val();
    let location = $("#txtLocation").val();
    let desc = $("#txtDescription").val();
    let participants = $("#txtParticipants").val();
    let color = $("#txtColor").val();
    // console.log(text);
    if(!title){
        alert("Error, must fill out title field!");
        return; // can not continue
    }

    let theTask = new Task(isImportant, title, desc, location, participants, color, date);
    console.log(theTask);
    console.log(JSON.stringify(theTask));

    $.ajax({
        type: "POST",
        url: "https://fsdiapi.azurewebsites.net/api/tasks/",
        data: JSON.stringify(theTask),
        contentType: "application/json",
        success: function(response){
            console.log("Server says:", response);
            let savedTask = JSON.parse(response);

            displayTask(savedTask);
            clearForm();
        },
        error: function(details){
            console.log("Save failed", details);
        }
    })

    
}

function clearForm(){
    $("#txtTitle").val("");
    $("#txtDueDate").val("");
    $("#txtLocation").val("");
    $("#txtDescription").val("");
    $("#txtParticipants").val("");
    $("#txtColor").val("");
}

function displayTask(task){
    let syntax = `<div class="task" style="border: 3px solid ${task.color}" >
        <div class="task-title">
        <h5>${task.title}</h5>
        <p>${task.description}</p>
        </div>

        <div class="task-middle">
            <label><i class="fas fa-map-marked"></i>${task.location}</label>
            <label><i class="fas fa-clock"></i>${task.dueDate}</label>
        </div>

    </div>`;

    $(".task-container").append(syntax) //
}

function fetchTasks(){
    $.ajax({
        
        url:"https://fsdiapi.azurewebsites.net/api/tasks",
        type: "GET",
        
        success: function(response){
            //console.log("Server says:", response);
            let allTasks = JSON.parse(response);

            for(let i=0; i<allTasks.length; i++){
                let task = allTasks[i];
                if(task.name === "Ray") {
                displayTask(task);
            }

        }  
            

        },
        error: function(details) {
            console.log("Req failed", details);
        }
    });
}

function deleteAllTasks(){
    $.ajax({
        type: 'DELETE',
        url: "https://restclass.azurewebsites.net/api/test",
        success: function(response){
            $(".task-container").html("");
        }
    
    })
}

//function testRequest(){
//    $.ajax({
//        url:"https://restclass.azurewebsites.net/api/test",
//        type: "GET",
//         success: function(response){    
            // console.log("Server says:", response);
        // },
        // error: function(details){
            // console.log("Req failed", details);
        // }
    // });
// }

function init(){
    console.log("My Calendar");

    //load data
    fetchTasks();

    // hook events
    $("#deleteTask").click(deleteAllTasks);

    $("#btnSave").click(saveTask);
    $(".iImportant").click(toggleImportant);
    $("#btnToggleDetails").click(toggleDetails);
}
window.onload = init;

// style="border: 10px solid ${task.color}
